import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import javax.swing.*;
public class User extends Frame implements ActionListener
{
	String q;
	String radio;
	JButton confirm;
	JButton logout;
	Label from,to,select_ride,fare;
	TextField fare_t;
	TextField from_t,to_t;
	Panel available_driver_p;
	Label available_driver,driver_id;
	TextArea available_driver_t;
	TextField driver_id_t;
	JButton take_ride;
	Label rides_history;
	TextArea history_ta;
	Label fare_perKM_info,discount_info,fare_perKM_info_t,discount_info_t;
	Label username_settings,oldpassword_settings,newpassword_settings,confirmpassword_settings;
	TextField username_settings_t,oldpassword_settings_t,newpassword_settings_t,confirmpassword_settings_t;
	JButton alter_settings;
	JRadioButton car,bike;
	ButtonGroup grp;
	Panel Rides_p,History_p,Info_p,Settings_p;
	JButton Rides,History,Info,Settings;
	int f_l_d,t_l_d;
	String Catagory;
	int Cu_id;
public User(int cu_id,String catagory)
{
	super("User");
	
	    Catagory = catagory;
		Cu_id = cu_id;
	
	    setBounds(500,400,342,300);
	    setVisible(true);
		setLayout(null);
	    
		Rides = new JButton("Rides");
		Rides.setBounds(8,32,81,40);
		add(Rides);
		
		History = new JButton("History");
		History.setBounds(89,32,82,40);
		add(History);
		
		Info = new JButton("Info");
		Info.setBounds(171,32,81,40);
		add(Info);
		
		Settings = new JButton("Settings");
		Settings.setBounds(252,32,82,40);
		add(Settings);
		
		
		
		Rides_p = new Panel();
		Rides_p.setBounds(0,73,342,227);
		Rides_p.setBackground(Color.gray);
		Rides_p.setLayout(null);
		this.add(Rides_p);
	
		
		History_p = new Panel();
		History_p.setBounds(0,73,342,227);
	    History_p.setBackground(Color.gray);
		History_p.setLayout(null);
	    this.add(History_p); 
		
		
		Info_p = new Panel();
		Info_p.setBounds(0,73,342,227);
		Info_p.setBackground(Color.gray);
		Info_p.setLayout(null);
		this.add(Info_p);
		
		Settings_p = new Panel();
		Settings_p.setBounds(0,73,342,227);
		Settings_p.setBackground(Color.gray);
		Settings_p.setLayout(null);
		this.add(Settings_p);
		
		available_driver_p = new Panel();
		available_driver_p.setBounds(0,73,342,227);
		available_driver_p.setBackground(Color.gray);
		available_driver_p.setLayout(null);
		this.add(available_driver_p);
		
		Rides.addActionListener(this);
		History.addActionListener(this);
		Info.addActionListener(this);
		Settings.addActionListener(this);
		
		
}

public void actionPerformed(ActionEvent ae)
{
	String s = ae.getActionCommand();
	String from_s;
	String to_s;
	String fare_s;
	String dr_id ;
	ResultSet rs = null;
	ResultSet rs1 = null;
	DataAccess da=new DataAccess();
	if(s.equals("Rides"))
	{
		Rides_p.setVisible(true);
		History_p.setVisible(false);
		Settings_p.setVisible(false);
		Info_p.setVisible(false);
		String f_lid,t_lid;
		
		logout = new JButton("Logout");
		logout.setBounds(240,190,90,15);
		Rides_p.add(logout);
		logout.addActionListener(this);
		
		from = new Label("From:");
		from.setBounds(40,47,40,17);
		Rides_p.add(from);
		
		to = new Label("To:");
		to.setBounds(170,47,20,17);
		Rides_p.add(to);
		
		select_ride = new Label("Select Ride:");
		select_ride.setBounds(65,90,90,17);;
		Rides_p.add(select_ride);
		
		grp = new ButtonGroup();
		
		car = new JRadioButton("Car");
		car.setBounds(150,90,50,20);
		car.setBackground(Color.gray);
		Rides_p.add(car);
		car.addActionListener(this);
		
		bike = new JRadioButton("Bike");
		bike.setBounds(200,90,50,20);
		bike.setBackground(Color.gray);
		Rides_p.add(bike);
		bike.addActionListener(this);
		
		grp.add(car);
		grp.add(bike);
		
		fare = new Label("Fare:");
		fare.setBounds(100,138,40,17);
		Rides_p.add(fare);
		
		fare_t = new TextField();
		fare_t.setBounds(141,138,50,20);
		Rides_p.add(fare_t);
		
		from_t = new TextField();
		from_t.setBounds(90,47,50,17);
		Rides_p.add(from_t);
		
		to_t = new TextField();
		to_t.setBounds(200,47,50,17);
		Rides_p.add(to_t);
		
		confirm = new JButton("Confirm");
		confirm.setBounds(120,180,90,30);
		Rides_p.add(confirm);
		confirm.addActionListener(this);
		
	}
	else if(s.equals("Logout"))
	{
		Login login = new Login(Catagory);
		this.setVisible(false);
	}
	else if (s.equals("Bike") || s.equals("Car"))
	{
		int count=0;
		 from_s = from_t.getText();
		 to_s = to_t.getText();
		if(from_s.length() ==0 || to_s.length()==0){
			JOptionPane.showMessageDialog(this,"Fillup all the required field");
		}
		else{
		String q = "select * from `locations`" ;
			 da=new DataAccess();
			 rs = da.getData(q);
			
			try{
				while(rs.next())
				{
					String pl = rs.getString("places");
					if(pl.equals(from_s))
					{
						count++;
					}
				}
				rs = null;
				rs = da.getData(q);
				while(rs.next())
				{
					String pl = rs.getString("places");
					if(pl.equals(to_s))
					{
						count++;
					}	
				}
				
				
				if(count == 2){
					String f_l_id = "select l_id from `locations` where places = '"+ from_s +"'";
					String t_l_id = "select l_id from `locations` where places = '"+ to_s +"'";
					rs = da.getData(f_l_id);
					rs1 = da.getData(t_l_id);
					rs.next();
					rs1.next();
					
					 f_l_d = rs.getInt("l_id");
					 t_l_d = rs1.getInt("l_id");
					String q_d ="insert into `rides_info`(from_L_id,to_L_id)" + "values ('"+f_l_id+"','"+t_l_id+"')";
				}
				else {
					JOptionPane.showMessageDialog(this,"location not found !");	
				}
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			int f = 40;
				if (s.equals("Bike")){
					f=f-15;
				}
			try{
					
				radio = "s";
				String loc_q = "select * from `locations` where places = '"+from_s+"'";
				rs = da.getData(loc_q);
				rs.next();
				int la = rs.getInt("latitude");
				int lon = rs.getInt("longitude");
				double from_0point = (lon-la)/2;
				
				loc_q = "select * from `locations` where places = '"+to_s+"'";
				rs = da.getData(loc_q);
				rs.next();
				la = rs.getInt("latitude");
				lon = rs.getInt("longitude");
				double to_0point = (lon-la)/2;
				double dist = (from_0point+to_0point)/2;
				fare_s = String.valueOf(dist*f);
				
				fare_t.setText(fare_s) ;
				Rides_p.add(fare_t);
			
			}
			catch (SQLException e)
			{	
				e.printStackTrace();
			} 
		}
	}
	else if (s.equals("Confirm"))
	{
		int count=0;
		 from_s = from_t.getText();
		 to_s = to_t.getText();
		 fare_s = fare_t.getText();
		if(from_s.length() ==0 || to_s.length()==0 || radio != "s"){
			JOptionPane.showMessageDialog(this,"Fillup all the required field");
		}
		else{
			q="select d_id, d_name, rating, l.places from `drivers` d, `locations` l where d.l_id = l.l_id and d.status <> 0";
			da = new DataAccess();
			rs = da.getData(q);
			
			
		  Rides_p.setVisible(false);
		  History_p.setVisible(false);
		  Settings_p.setVisible(false);
		  Info_p.setVisible(false);
		  available_driver_p.setVisible(true);
		  
		  available_driver = new Label("Available Drivers");
		  available_driver.setBounds(125,20,100,17);
		  available_driver_p.add(available_driver);
		  
		  available_driver_t = new TextArea();
		  available_driver_t.setBounds(5,40,330,120);
		  available_driver_p.add(available_driver_t);
		  
		  driver_id = new Label("Enter drivers id :");
		  driver_id.setBounds(15,170,125,17);
		  available_driver_p.add(driver_id);
		  
		  driver_id_t = new TextField();
		  driver_id_t.setBounds(140,170,15,20);
		  available_driver_p.add(driver_id_t);
		  
		  take_ride = new JButton("Take ride");
		  take_ride.setBounds(160,165,100,30);
		  available_driver_p.add(take_ride);
		  
			try
			{
				while(rs.next())
				{
			      dr_id = rs.getString("d_id");
			      String d_name = rs.getString("d_name");
			      String rating = rs.getString("rating");
			      String places = rs.getString("places");
				  
				  String full = "Id: "+dr_id +" "+ d_name + " is available at " + places + ". His rating is " + rating;
				  available_driver_t.append(full+"\n");
				}
			}
			catch (SQLException e)
			{	
				e.printStackTrace();
			}
		  take_ride.addActionListener(this);
		}
		
	}
	else if (s.equals("Take ride")){
		if(driver_id_t.getText().length() == 0){
			JOptionPane.showMessageDialog(this,"Please input the driver id to confirm your ride");
		}
		else{
			JOptionPane.showMessageDialog(this,"Your request is sent. Please wait till the rider respond");
			
			  q="insert into `pending_request` (from_id,to_id,c_id,d_id) values ("+f_l_d+","+t_l_d+","+Cu_id+","+driver_id_t.getText()+")";
			  
				//q = "update `drivers` set status = "+Cu_id+" where d_id='"+driver_id_t.getText()+"'";
				da.updateDB(q);
			
			
		}
		
		
	}		
	
	else if(s.equals("History"))
	{
		ResultSet rs_a = null;
		Rides_p.setVisible(false);
		History_p.setVisible(true);
		Settings_p.setVisible(false);
		Info_p.setVisible(false);
		
		rides_history = new Label("Rides history");
		rides_history.setBounds(150,15,100,20);
		History_p.add(rides_history);
		
		history_ta = new TextArea();
		history_ta.setBounds(10,40,332,180);
		History_p.add(history_ta);
		
		String ride_no,date,q;
		int from_l,to_l;
		String amount;
		q = "select * from `rides_info`";
		 da=new DataAccess();
		 rs = da.getData(q);
		
		int count=0 ;
		try{
			while(rs.next())
			{
				ride_no = rs.getString("ride_no");
				from_l = rs.getInt("from_L_id");
				to_l = rs.getInt("to_L_id");
				amount = rs.getString("amount");
				date = rs.getString("date");
				
				String from_q = "select places from `locations` where l_id ="+from_l;
				rs_a = da.getData(from_q);
				rs_a.next();
				String from_pl = rs_a.getString("places");
				
				String to_q = "select places from `locations` where l_id ="+to_l;
				rs_a = da.getData(to_q);
				rs_a.next();
				String to_pl = rs_a.getString("places");
				
				String str=ride_no+":"+from_pl+":"+to_pl+":"+amount+":"+date;
				history_ta.append(str+"\n");				
			}
		}
		catch (SQLException e)
		{	
			e.printStackTrace();
		}
		
	}
	
	else if(s.equals("Info"))
	{
		Rides_p.setVisible(false);
		History_p.setVisible(false);
		Settings_p.setVisible(false);
		Info_p.setVisible(true);
		
		fare_perKM_info = new Label("Fare per km :");
		fare_perKM_info.setBounds(70,70,80,17);
		Info_p.add(fare_perKM_info);
		
		fare_perKM_info_t = new Label("40TK");
		fare_perKM_info_t.setBounds(155,70,80,20);
		Info_p.add(fare_perKM_info_t);
		
		discount_info = new Label("Discount :");
		discount_info.setBounds(70,90,85,17);
		Info_p.add(discount_info);
		
		discount_info_t = new Label("0%");
		discount_info_t.setBounds(155,90,80,20);
		Info_p.add(discount_info_t);
	}
	
	else if (s.equals("Settings"))
	{
		Rides_p.setVisible(false);
		History_p.setVisible(false);
		Settings_p.setVisible(true);
		Info_p.setVisible(false);
		
		username_settings = new Label("Username :");
		username_settings.setBounds(40,40,70,17);
		Settings_p.add(username_settings);
		
		username_settings_t = new TextField();
		username_settings_t.setBounds(115,40,70,20);
		Settings_p.add(username_settings_t);
		
		oldpassword_settings = new Label("Old Password :");
		oldpassword_settings.setBounds(40,65,90,17);
		Settings_p.add(oldpassword_settings);
		
		oldpassword_settings_t = new TextField();
		oldpassword_settings_t.setBounds(135,65,90,20);
		Settings_p.add(oldpassword_settings_t);
		
		newpassword_settings = new Label("New Password :");
		newpassword_settings.setBounds(40,90,95,17);
		Settings_p.add(newpassword_settings);
		
		newpassword_settings_t = new TextField();
		newpassword_settings_t.setBounds(140,90,90,20);
		Settings_p.add(newpassword_settings_t);
		
		confirmpassword_settings = new Label("Confirm Password :");
        confirmpassword_settings.setBounds(40,115,110,17);
        Settings_p.add(confirmpassword_settings);

        confirmpassword_settings_t = new TextField();
        confirmpassword_settings_t.setBounds(155,115,90,20);
        Settings_p.add(confirmpassword_settings_t);		
		
		alter_settings = new JButton("Alter");
		alter_settings.setBounds(160,160,80,30);
		Settings_p.add(alter_settings);
		alter_settings.addActionListener(this);
	}
	else if (s.equals("Alter")){
		int count = 0 ;
		String username_settings_s = username_settings_t.getText();
		String oldpassword_settings_s = oldpassword_settings_t.getText();
		String newpassword_settings_s = newpassword_settings_t.getText();
		String confirmpassword_settings_s = confirmpassword_settings_t.getText();
		if(newpassword_settings_s.equals(confirmpassword_settings_s)){
			if(username_settings_s.length() ==0 || oldpassword_settings_s.length()==0 || newpassword_settings_s.length()==0 || confirmpassword_settings_s.length()==0){
				JOptionPane.showMessageDialog(this,"fillup all the required field");
			}
			else{
				String q = "select * from `identity`" ;
				 da=new DataAccess();
				 rs = da.getData(q);
				
				try{
					while(rs.next())
					{
						String username = rs.getString("username");
						String passWord = rs.getString("password");
						//System.out.println(t1.getlength());
						if(username.equals(username_settings_s) && passWord.equals(oldpassword_settings_s))
						{
							count  =1;
						   q = "update `identity` set password = '"+ newpassword_settings_s + "'where password = '" + oldpassword_settings_s +"'";	
						   da.updateDB(q);
						}
					}
					
					
					if(count == 1){
						JOptionPane.showMessageDialog(this,"password successfully changed!");
	
					}
					else {
						JOptionPane.showMessageDialog(this,"incorrect username or password .try again..");	
					}
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			//System.out.println("sam"+to_s);
			}
		}
		else{
			JOptionPane.showMessageDialog(this,"password donot match");	
		}
		
	}

	}
	
}
