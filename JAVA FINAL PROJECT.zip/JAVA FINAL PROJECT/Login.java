import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class Login extends Frame implements ActionListener
{
	public TextField t1,t2;
	public String Catagory;
	public Login(String catagory)
	{
		super("Login");
		Catagory = catagory;
		 Label userName,password;
		 Button login,signup,quit;
		setBounds(500,400,300,300);
		setVisible(true);
		setLayout(null);
		userName = new Label("User Name:");
		userName.setBounds(60,100,70,17);
		password = new Label("Password:");
		password.setBounds(60,140,70,17);
		t1 = new TextField();
		t1.setBounds(130,100,100,20);
		t2 = new TextField();
		t2.setBounds(125,140,100,20);
		login = new Button("Login");
		login.setBounds(185,180,40,30);
		signup = new Button("Back");
		signup.setBounds(120,180,50,30);
		quit = new Button("Quit");
		quit.setBackground(Color.gray);
		quit.setBounds(215,250,50,20);
		quit.addActionListener(this);
		signup.addActionListener(this);
		login.addActionListener(this);
		add(quit);
		add(signup);
		add(login);
		add(t1);
		add(t2);
		add(userName);
		add(password);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String s = ae.getActionCommand();
		String tf1 = t1.getText();
		String tf2 = t1.getText();
        int ident_id,cu_id,dr_id;
		String q;
			if(s.equals("Back"))            //wreiuhtbgihrwftgiuoh
			{
			   mainWindow mainwindow = new mainWindow();
			   this.setVisible(false);
			}
			else if(s.equals("Login")){

				if(tf1.length()==0 || tf2.length()==0){ JOptionPane.showMessageDialog(this,"enter your username and password correctly to login");}
				else{
					//System.out.println(t1.length());
					String username,passWord,insert;
					q = "select * from `identity`";
					DataAccess da=new DataAccess();
					ResultSet rs = da.getData(q);
					
					int count=0 ;
					try{
						while(rs.next())
						{
							username = rs.getString("username");
							passWord = rs.getString("password");
							//System.out.println(t1.getlength());
							if(username.equals(t1.getText()) && passWord.equals(t2.getText()))
							{
								ident_id = rs.getInt("identity_id");
								count  =1;
							   JOptionPane.showMessageDialog(this,"Login Successful");
                                if(count == 1 && Catagory == "Customer")
                                {		
                                    q = "select c_id from `customers` where identity_id =" + ident_id;
									rs = da.getData(q);
									rs.next();
									cu_id= rs.getInt("c_id");
							        User u = new User(cu_id,Catagory);                                 //User class will be called.
								    this.setVisible(false);                               //User class will be called.
								}
								else if (count == 1 && Catagory == "Driver")
								{
									q = "select d_id from `drivers` where identity_id =" + ident_id;
									rs = da.getData(q);
									rs.next();
									dr_id= rs.getInt("d_id");
									insert="update `drivers` set status = 1 where d_name='"+username+"'";
									User_D user_d = new User_D(dr_id,Catagory);                                //Driver class will be called.
									da.updateDB(insert);
									this.setVisible(false);
								}
							}
						}
					}
					catch (SQLException e)
					{	
						e.printStackTrace();
					}
					
					if(count == 0){
						//System.out.println(t1.length());
							JOptionPane.showMessageDialog(this,"Incorrect username or password");
							
						}
				}
							
			}
			else if (s.equals("Quit"))
			{
				System.exit(0);
			}
		
	}
	
	
} 