import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import javax.swing.*;
public class User_D extends Frame implements ActionListener
{
	JButton Request,History,Info,Settings;
	JButton logout;
	Panel Request_p,History_p,Info_p,Settings_p;
	Label Ride_request;
	TextArea Request_data;
	JButton Take_ride;
	Label rides_history;
	TextArea history_ta;
	Label fare_perKM_info,discount_info,fare_perKM_info_t,discount_info_t;
	Label username_settings,oldpassword_settings,newpassword_settings,confirmpassword_settings;
	TextField username_settings_t,oldpassword_settings_t,newpassword_settings_t,confirmpassword_settings_t;
	JButton alter_settings;
	String Catagory;
	int Dr_id;
	int cu_id,from_id,to_id;
	public User_D(int dr_id,String catagory)
	{
		super("User:Driver");
		
		Catagory = catagory;
		Dr_id = dr_id;
		
		setBounds(500,400,342,300);
	    setVisible(true);
		setLayout(null);
		
		Request = new JButton("Request");
		Request.setBounds(8,32,81,40);
		add(Request);
		
		History = new JButton("History");
		History.setBounds(89,32,82,40);
		add(History);
		
		Info = new JButton("Info");
		Info.setBounds(171,32,81,40);
		add(Info);
		
		Settings = new JButton("Settings");
		Settings.setBounds(252,32,82,40);
		add(Settings);
		
		Request_p = new Panel();
		Request_p.setBounds(0,73,342,227);
		Request_p.setBackground(Color.gray);
		Request_p.setLayout(null);
		this.add(Request_p);
	
		
		History_p = new Panel();
		History_p.setBounds(0,73,342,227);
	    History_p.setBackground(Color.gray);
		History_p.setLayout(null);
	    this.add(History_p); 
		
		
		Info_p = new Panel();
		Info_p.setBounds(0,73,342,227);
		Info_p.setBackground(Color.gray);
		Info_p.setLayout(null);
		this.add(Info_p);
		
		
		Settings_p = new Panel();
		Settings_p.setBounds(0,73,342,227);
		Settings_p.setBackground(Color.gray);
		Settings_p.setLayout(null);
		this.add(Settings_p);
		
		
		Request.addActionListener(this);
		History.addActionListener(this);
		Info.addActionListener(this);
		Settings.addActionListener(this);
	}
    public void actionPerformed(ActionEvent ae)
	{
		
		String s = ae.getActionCommand();
		ResultSet rs = null;
	    DataAccess da=new DataAccess();
		if(s.equals("Request"))
		{
			Request_p.setVisible(true);
		    History_p.setVisible(false);
		    Settings_p.setVisible(false);
		    Info_p.setVisible(false);
			
			logout = new JButton("Logout");       //new
		    logout.setBounds(240,190,90,15);       //new
		    Request_p.add(logout);                   //new
		    logout.addActionListener(this);      //new
			
			Ride_request = new Label("Ride Request");
			Ride_request.setBounds(125,20,75,17);
			Request_p.add(Ride_request);
			
			Request_data = new TextArea();
			Request_data.setBounds(5,40,330,120);
			Request_p.add(Request_data);
			
			Take_ride = new JButton("Take Ride");
			Take_ride.setBounds(115,165,100,30);
			Request_p.add(Take_ride);
			try
			{
				String record="select * from `pending_request` where d_id = "+Dr_id;
				rs = da.getData(record);
				rs.next();
				 from_id = rs.getInt("from_id");
				 to_id = rs.getInt("to_id");
				 cu_id = rs.getInt("c_id");
				String from_s = "select places from `locations` where l_id = "+from_id;
				rs = da.getData(from_s);
				rs.next();
				from_s = rs.getString("places");
				
				String to_s = "select places from `locations` where l_id = "+to_id;
				rs = da.getData(to_s);
				rs.next();
				to_s = rs.getString("places");
				
				String c_s = "select c_name from `customers` where c_id = "+cu_id;
				rs = da.getData(c_s);
				rs.next();
				c_s = rs.getString("c_name");
				
				String str = c_s+" is requesting to go from "+from_s+" to "+to_s;
				Request_data.append(str+"\n");
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			Take_ride.addActionListener(this);
		}
		else if(s.equals("Take Ride"))
	   {
		   
		   String q = "delete from `pending_request` where d_id = "+Dr_id;
		   da.updateDB(q);
		   q= "insert into `rides_info`  (d_id,c_id,from_L_id,to_L_id) values ("+Dr_id+","+cu_id+","+from_id+","+to_id+") ";
		   da.updateDB(q);
	   }
		else if(s.equals("Logout"))
	   {
       this.setVisible(false);
	   String q = "update `drivers` set status = 0 where d_id="+Dr_id;
	   da.updateDB(q);
	   Login login = new Login(Catagory);
	   }
		//If user press History
		else if(s.equals("History"))
	   {
		ResultSet rs_a = null;
		
		Request_p.setVisible(false);
		History_p.setVisible(true);
		Settings_p.setVisible(false);
		Info_p.setVisible(false);
		
		rides_history = new Label("Rides history");
		rides_history.setBounds(150,15,100,20);
		History_p.add(rides_history);
		
		history_ta = new TextArea();
		history_ta.setBounds(10,40,332,180);
		History_p.add(history_ta);
		
		String ride_no,date,q;
		int from_l,to_l;
		String amount;
		q = "select * from `rides_info`";
		 da=new DataAccess();
		 rs = da.getData(q);
		
		int count=0 ;
		try{
			while(rs.next())
			{
				ride_no = rs.getString("ride_no");
				from_l = rs.getInt("from_L_id");
				to_l = rs.getInt("to_L_id");
				amount = rs.getString("amount");
				date = rs.getString("date");
				
				String from_q = "select places from `locations` where l_id ="+from_l;
				rs_a = da.getData(from_q);
				rs_a.next();
				String from_pl = rs_a.getString("places");
				
				String to_q = "select places from `locations` where l_id ="+to_l;
				rs_a = da.getData(to_q);
				rs_a.next();
				String to_pl = rs_a.getString("places");
				
				String str=ride_no+":"+from_pl+":"+to_pl+":"+amount+":"+date;
				history_ta.append(str+"\n");				
			}
		}
		catch (SQLException e)
		{	
			e.printStackTrace();
		}
	   }
		//If user press Info
		else if(s.equals("Info"))
	   {
		Request_p.setVisible(false);
		History_p.setVisible(false);
		Settings_p.setVisible(false);
		Info_p.setVisible(true);
		
		fare_perKM_info = new Label("Fare per km :");
		fare_perKM_info.setBounds(95,70,80,17);
		Info_p.add(fare_perKM_info);
		
		fare_perKM_info_t = new Label("40TK");
		fare_perKM_info_t.setBounds(180,70,80,20);
		Info_p.add(fare_perKM_info_t);
		
		discount_info = new Label("Your cut :");
		discount_info.setBounds(95,100,80,17);
		Info_p.add(discount_info);
		
		discount_info_t = new Label("85%");
		discount_info_t.setBounds(180,100,80,20);
		Info_p.add(discount_info_t);
	   }
	   //If user press Settings
	   else if (s.equals("Settings"))
	   {
		Request_p.setVisible(false);
		History_p.setVisible(false);
		Settings_p.setVisible(true);
		Info_p.setVisible(false);
		
		username_settings = new Label("Username :");
		username_settings.setBounds(40,40,70,17);
		Settings_p.add(username_settings);
		
		username_settings_t = new TextField();
		username_settings_t.setBounds(115,40,70,20);
		Settings_p.add(username_settings_t);
		
		oldpassword_settings = new Label("Old Password :");
		oldpassword_settings.setBounds(40,65,90,17);
		Settings_p.add(oldpassword_settings);
		
		oldpassword_settings_t = new TextField();
		oldpassword_settings_t.setBounds(135,65,90,20);
		Settings_p.add(oldpassword_settings_t);
		
		newpassword_settings = new Label("New Password :");
		newpassword_settings.setBounds(40,90,95,17);
		Settings_p.add(newpassword_settings);
		
		newpassword_settings_t = new TextField();
		newpassword_settings_t.setBounds(140,90,90,20);
		Settings_p.add(newpassword_settings_t);
		
		confirmpassword_settings = new Label("Confirm Password :");
        confirmpassword_settings.setBounds(40,115,110,17);
        Settings_p.add(confirmpassword_settings);

        confirmpassword_settings_t = new TextField();
        confirmpassword_settings_t.setBounds(155,115,90,20);
        Settings_p.add(confirmpassword_settings_t);		
		
		alter_settings = new JButton("Alter");
		alter_settings.setBounds(160,160,80,30);
		Settings_p.add(alter_settings);
		alter_settings.addActionListener(this);
	   }      //Alter is the button which is situated in Settings panel.
	   else if (s.equals("Alter")){
		int count = 0 ;
		String username_settings_s = username_settings_t.getText();
		String oldpassword_settings_s = oldpassword_settings_t.getText();
		String newpassword_settings_s = newpassword_settings_t.getText();
		String confirmpassword_settings_s = confirmpassword_settings_t.getText();
		if(newpassword_settings_s.equals(confirmpassword_settings_s)){
			if(username_settings_s.length() ==0 || oldpassword_settings_s.length()==0 || newpassword_settings_s.length()==0 || confirmpassword_settings_s.length()==0){
				JOptionPane.showMessageDialog(this,"fillup all the required field");
			}
			else{
				String q = "select * from `identity`" ;
				 da=new DataAccess();
				 rs = da.getData(q);
				
				try{
					while(rs.next())
					{
						String username = rs.getString("username");
						String passWord = rs.getString("password");
						//System.out.println(t1.getlength());
						if(username.equals(username_settings_s) && passWord.equals(oldpassword_settings_s))
						{
							count  =1;
						   q = "update `identity` set password = '"+ newpassword_settings_s + "'where password = '" + oldpassword_settings_s +"'";	
						   da.updateDB(q);
						}
					}
					
					
					if(count == 1){
						JOptionPane.showMessageDialog(this,"password successfully changed!");
	
					}
					else {
						JOptionPane.showMessageDialog(this,"incorrect username or password .try again..");	
					}
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			//System.out.println("sam"+to_s);
			}
		}
		else{
			JOptionPane.showMessageDialog(this,"Password do not match");	
		}
		
	   }
	}
}