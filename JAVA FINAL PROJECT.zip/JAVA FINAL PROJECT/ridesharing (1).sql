-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2019 at 06:37 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ridesharing`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts_info`
--

CREATE TABLE `contacts_info` (
  `contact_id` int(11) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(35) NOT NULL,
  `l_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts_info`
--

INSERT INTO `contacts_info` (`contact_id`, `phone`, `email`, `l_id`) VALUES
(36, 111, '111', NULL),
(37, 111, '111', NULL),
(38, 111, '111', NULL),
(39, 555, '111', NULL),
(40, 111, '555', NULL),
(41, 111, '555', NULL),
(42, 111, '222', NULL),
(43, 111, '222', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(20) NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `l_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `identity_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`c_id`, `c_name`, `rating`, `l_id`, `contact_id`, `identity_id`) VALUES
(1, 'rahim', 5, 10, 1, 1),
(2, 'abdur', 3, 15, 2, 4),
(3, 'sam', NULL, 1, 36, 70),
(8, 'post', NULL, 1, 36, 38),
(9, 'aiuy', NULL, 1, 36, 39),
(10, 'urm', NULL, 1, 36, 40),
(11, '123p', NULL, 1, 40, 41),
(12, '666', NULL, 1, 40, 42),
(13, 'you', NULL, 2, 42, 43),
(14, 'olo', NULL, 3, 42, 44);

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `d_id` int(11) NOT NULL,
  `v_type` varchar(10) NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `d_name` varchar(20) NOT NULL,
  `l_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `identity_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`d_id`, `v_type`, `rating`, `d_name`, `l_id`, `contact_id`, `status`, `identity_id`) VALUES
(1, 'car', 4, 'shabab', 20, 1, 0, 0),
(2, 'bike', 5, 'kabir', 15, 2, 0, 0),
(7, 'truck', NULL, 'prottasha', NULL, NULL, 0, 0),
(12, 'car', NULL, 'sam_bai', NULL, NULL, 0, 0),
(13, '', NULL, '', NULL, NULL, 0, 0),
(14, '', NULL, '', NULL, NULL, 0, 0),
(15, '', NULL, '', NULL, NULL, 0, 0),
(16, 'car', NULL, 'player', NULL, NULL, 0, 0),
(17, '', NULL, '', NULL, NULL, 0, 0),
(18, 'bike', NULL, 'bfg_player', NULL, NULL, 0, 0),
(19, 'car', NULL, 'hariz', NULL, NULL, 0, 0),
(20, 'car', NULL, 'samson', NULL, NULL, 0, 0),
(21, 'car', NULL, 'sam', 1, NULL, 7, 22),
(22, '', NULL, '', NULL, NULL, 0, 0),
(23, 'car', NULL, 'samson', 2, NULL, 3, 11),
(24, 'car', NULL, 'building', NULL, NULL, 0, 0),
(25, 'cr', NULL, 'pkkk', NULL, NULL, 0, 0),
(26, 'huk', NULL, 'sams', NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `identity`
--

CREATE TABLE `identity` (
  `identity_id` int(20) NOT NULL,
  `password` varchar(15) NOT NULL,
  `username` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `identity`
--

INSERT INTO `identity` (`identity_id`, `password`, `username`) VALUES
(1, '546', 'wer546'),
(2, 'bfg', 'bfg'),
(4, '124', '124'),
(5, 'pkkk', 'pk'),
(6, 'hariz', 'hanz'),
(7, '789', '789'),
(8, 'bd', 'bd'),
(9, '5486', '5486'),
(10, '12', '12'),
(11, '891', '891'),
(15, 'samdol', 'samdol'),
(17, '1245', 'zihan1245'),
(18, '12345', 'sam12345'),
(23, 'sam', 'samS'),
(24, '789', 's789'),
(25, '894', 'sam894'),
(26, 'SA', 'SA'),
(27, 'easmin', 'easmin'),
(28, 'mridul', 'mridul'),
(29, 'sam', 'YOHAN'),
(30, 'LOBI', 'LOBI'),
(31, 'tota', 'tota'),
(32, 'hawa', 'hawa'),
(33, 'purna', 'purna'),
(34, 'hyre', 'hyre'),
(35, 'sami', 'sami'),
(36, 'sadi', 'sadi'),
(37, 'samir', 'samir'),
(38, 'post', 'post'),
(39, 'samueq', 'samueq'),
(40, 'doli', 'doli'),
(41, 'SANDY', 'SANDY'),
(42, 'opi', 'opi'),
(43, 'you', 'you'),
(44, 'olo', 'olo'),
(70, 'sam', 'sam');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `l_id` int(11) NOT NULL,
  `latitude` int(11) NOT NULL,
  `longitude` int(11) NOT NULL,
  `places` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`l_id`, `latitude`, `longitude`, `places`) VALUES
(1, 5, 10, 'aiub'),
(2, 15, 20, 'banani'),
(3, 45, 80, 'uttara');

-- --------------------------------------------------------

--
-- Table structure for table `pending_request`
--

CREATE TABLE `pending_request` (
  `p_request_id` int(20) NOT NULL,
  `from_id` int(20) NOT NULL,
  `to_id` int(20) NOT NULL,
  `c_id` int(20) NOT NULL,
  `d_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rides_info`
--

CREATE TABLE `rides_info` (
  `ride_no` int(11) NOT NULL,
  `d_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `from_L_id` int(11) NOT NULL,
  `to_L_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='to';

--
-- Dumping data for table `rides_info`
--

INSERT INTO `rides_info` (`ride_no`, `d_id`, `c_id`, `from_L_id`, `to_L_id`, `amount`, `date`) VALUES
(1, 1, 2, 1, 2, 500, '2019-07-16'),
(2, 2, 2, 3, 1, 200, '2019-07-02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts_info`
--
ALTER TABLE `contacts_info`
  ADD PRIMARY KEY (`contact_id`),
  ADD KEY `l_id` (`l_id`),
  ADD KEY `l_id_2` (`l_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`c_id`),
  ADD KEY `l_id` (`l_id`),
  ADD KEY `contact_id` (`contact_id`),
  ADD KEY `rating` (`rating`),
  ADD KEY `rating_2` (`rating`),
  ADD KEY `identity_id` (`identity_id`),
  ADD KEY `identity_id_2` (`identity_id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`d_id`),
  ADD KEY `contact_id` (`contact_id`),
  ADD KEY `l_id` (`l_id`),
  ADD KEY `identity_id` (`identity_id`);

--
-- Indexes for table `identity`
--
ALTER TABLE `identity`
  ADD PRIMARY KEY (`identity_id`),
  ADD UNIQUE KEY `username` (`identity_id`),
  ADD UNIQUE KEY `identity_id` (`identity_id`),
  ADD UNIQUE KEY `identity_id_2` (`identity_id`),
  ADD UNIQUE KEY `username_3` (`username`),
  ADD UNIQUE KEY `username_4` (`username`),
  ADD KEY `username_2` (`identity_id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `pending_request`
--
ALTER TABLE `pending_request`
  ADD PRIMARY KEY (`p_request_id`);

--
-- Indexes for table `rides_info`
--
ALTER TABLE `rides_info`
  ADD PRIMARY KEY (`ride_no`),
  ADD KEY `r_id` (`d_id`),
  ADD KEY `c_id` (`c_id`),
  ADD KEY `from_L_id` (`from_L_id`),
  ADD KEY `to_L_id` (`to_L_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts_info`
--
ALTER TABLE `contacts_info`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `identity`
--
ALTER TABLE `identity`
  MODIFY `identity_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `l_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pending_request`
--
ALTER TABLE `pending_request`
  MODIFY `p_request_id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rides_info`
--
ALTER TABLE `rides_info`
  MODIFY `ride_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
