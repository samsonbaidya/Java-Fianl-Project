import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Signup extends Frame implements ActionListener 
{
	TextField user_t,pass_t,vtype_t,phone_t,email_t,proname_t;
	public String Catagory;
	public Signup(String catagory)
	{
		super("Signup");
		Catagory = catagory;
		 Label userName,password,vtype,phone,email,profileName;
		 Button login,signup;
		setBounds(500,400,300,350);
		setVisible(true);
		setLayout(null);
		userName = new Label("User Name:");
		userName.setBounds(40,60,70,17);
		password = new Label("Password:");
		password.setBounds(40,90,70,17);
		vtype = new Label("Vehicle Type:");
		vtype.setBounds(40,120,80,17);
		phone = new Label("Phone Num:");
		phone.setBounds(40,150,80,17);
		email =new Label("Email:");
		email.setBounds(40,180,80,17);
		profileName = new Label("Profile Name");
		profileName.setBounds(40,210,80,17);
		user_t = new TextField();
		user_t.setBounds(125,60,100,20);
		pass_t = new TextField();
		pass_t.setBounds(125,90,100,20);
		vtype_t = new TextField();
		vtype_t.setBounds(125,120,100,20);
		phone_t = new TextField();
		phone_t.setBounds(125,150,100,20);
		email_t = new TextField();
		email_t.setBounds(125,180,100,20);
		proname_t = new TextField();
		proname_t.setBounds(125,210,100,20);
		login = new Button("Login");
		login.setBounds(120,250,40,30);
		signup = new Button("Signup");
		signup.setBounds(175,250,50,30);
		signup.addActionListener(this);
		login.addActionListener(this);
		add(signup);
		add(login);
		add(user_t);
		add(pass_t);
		add(vtype_t);
		add(phone_t);
		add(email_t);
		add(proname_t);
		add(userName);
		add(password);
		add(vtype);
		add(phone);
		add(email);
		add(profileName);
	}

	public void actionPerformed(ActionEvent ae)
	{
		String s = ae.getActionCommand();
		if(s.equals("Login")) {
			Login log = new Login(Catagory);
			this.setVisible(false);
		}
		else if(s.equals("Signup"))
		{
			String s1,s2,s3,s4,s5,s6;
			s1 = user_t.getText();
			s2 = pass_t.getText();
			s3 = vtype_t.getText();
			s4 = phone_t.getText();
			s5 = email_t.getText();
			s6 = proname_t.getText();
			int count=0;
			
			if(s1.length() ==0 || s2.length() ==0 || s3.length() ==0 || s4.length() ==0 || s5.length() ==0 || s6.length() ==0 ){
				JOptionPane.showMessageDialog(this,"please fillup all the required field to signup successfully ");
			}
			else{
				String q = "select * from `identity`";
				DataAccess da=new DataAccess();
				ResultSet rs = da.getData(q);
				try{
					while(rs.next())
					{
						String username = rs.getString("username");
						//System.out.println(t1.getlength());
						if(username.equals(s1))
						{
							count  =1;
						 JOptionPane.showMessageDialog(this,"this username is already used try with  a different usename");	
						}
					}
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
					
				if(count == 0){
					String ProfileName,Vtype,UserName,Password,Phone,Email;
					ProfileName = proname_t.getText();
					Vtype = vtype_t.getText();
					UserName = user_t.getText();
					Password = pass_t.getText();
					Phone = phone_t.getText();
					Email = email_t.getText();
				
					q = "insert into `drivers`(d_name,v_type)" + "values ('"+ProfileName+"','"+Vtype+"')";
					da.updateDB(q);	
					q = "insert into `identity` (username,password) values ('"+UserName+"','"+Password+"')";	
					da.updateDB(q); 	
					q = "insert into `contacts_info` (phone,email) values ('"+Phone+"','"+Email+"')";
					da.updateDB(q);	
					mainWindow mW = new mainWindow();
					JOptionPane.showMessageDialog(this,"signup successfully ! \n please login to continue");
					this.setVisible(false);
				}
			}
				
			
	
		
		}
			
			
	}
}
	


