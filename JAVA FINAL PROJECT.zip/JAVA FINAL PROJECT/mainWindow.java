import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class mainWindow  extends Frame implements ActionListener{
	String catagory = "null";
	public mainWindow(){
		super("Main Window");
		Button login,signup,quit;
		JRadioButton Driver,Customer;
		ButtonGroup grp;
		setBounds(500,400,300,300);
		setVisible(true);
		setLayout(null);
		
		grp = new ButtonGroup();
		
		Customer = new JRadioButton("Customer");
		Customer.setBounds(60,90,90,17);
		add(Customer);
		
		Driver = new JRadioButton("Driver");
		Driver.setBounds(160,90,90,17);
		add(Driver);
		
		grp.add(Customer);
		grp.add(Driver);
		
		login = new Button("Login");
		login.setBounds(170,120,40,30);
		signup = new Button("Signup");
		signup.setBounds(105,120,50,30);
		add(signup);
		add(login);
		
		quit = new Button("Quit");
		quit.setBackground(Color.gray);
		quit.setBounds(215,250,50,20);
		
		add(quit);
		
		quit.addActionListener(this);
		Customer.addActionListener(this);
		Driver.addActionListener(this);
		signup.addActionListener(this);
		login.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String s = ae.getActionCommand();
		if(s.equals("Customer") || s.equals("Driver"))
		{
			catagory = s;
			System.out.println(catagory);
		}
		else if(s.equals("Signup") && catagory.equals("Driver"))
		{
		   Signup signup = new Signup(catagory);
		   this.setVisible(false);
		}
		else if (s.equals("Signup") && catagory.equals("Customer"))
		{	
		   Signup_C signup_c = new Signup_C(catagory);
		   this.setVisible(false);
		}
		else if (s.equals("Signup"))
		{
			JOptionPane.showMessageDialog(this,"Select whether you are a Driver or a Customer");
		}
		else if (s.equals("Login") && catagory.equals("null"))
		{
			System.out.println(catagory);
			JOptionPane.showMessageDialog(this,"Select whether you are a Driver or a Customer");
		}
		else if(s.equals("Login") && (catagory.equals("Customer") || catagory.equals("Driver")))
		{
			Login login = new Login(catagory);
		    this.setVisible(false);
		}
		else if (s.equals("Quit"))
			{
				System.exit(0);
			}
	}
	
}