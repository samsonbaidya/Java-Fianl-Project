import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Signup_C extends Frame implements ActionListener 
{
	TextField user_t,pass_t,address_t,phone_t,email_t,proname_t;
	public String Catagory;
	public Signup_C(String catagory)
	{
		super("Signup");
		Catagory = catagory;
		 Label userName,password,address,phone,email,profileName;
		 Button login,signup;
		setBounds(500,400,300,350);
		setVisible(true);
		setLayout(null);
		userName = new Label("User Name:");
		userName.setBounds(40,60,70,17);
		password = new Label("Password:");
		password.setBounds(40,90,70,17);
		address = new Label("Address:");
		address.setBounds(40,120,80,17);
		phone = new Label("Phone Num:");
		phone.setBounds(40,150,80,17);
		email =new Label("Email:");
		email.setBounds(40,180,80,17);
		profileName = new Label("Profile Name");
		profileName.setBounds(40,210,80,17);
		user_t = new TextField();
		user_t.setBounds(125,60,100,20);
		pass_t = new TextField();
		pass_t.setBounds(125,90,100,20);
		address_t = new TextField();
		address_t.setBounds(125,120,100,20);
		phone_t = new TextField();
		phone_t.setBounds(125,150,100,20);
		email_t = new TextField();
		email_t.setBounds(125,180,100,20);
		proname_t = new TextField();
		proname_t.setBounds(125,210,100,20);
		login = new Button("Login");
		login.setBounds(120,250,40,30);
		signup = new Button("Signup");
		signup.setBounds(175,250,50,30);
		signup.addActionListener(this);
		login.addActionListener(this);
		add(signup);
		add(login);
		add(user_t);
		add(pass_t);
		add(address_t);
		add(phone_t);
		add(email_t);
		add(proname_t);
		add(userName);
		add(password);
		add(address);
		add(phone);
		add(email);
		add(profileName);
	}

	public void actionPerformed(ActionEvent ae)
	{
		String s = ae.getActionCommand();
		if(s.equals("Login")) {
			Login log = new Login(Catagory);
			this.setVisible(false);
		}
		else if(s.equals("Signup"))
		{
			String s1,s2,s3,s4,s5,s6;
			s1 = user_t.getText();
			s2 = pass_t.getText();
			s3 = address_t.getText();
			s4 = phone_t.getText();
			s5 = email_t.getText();
			s6 = proname_t.getText();
			int location=0;
			int count=0;
			int count_a =0;
			
			if(s1.length() ==0 || s2.length() ==0 || s3.length() ==0 || s4.length() ==0 || s5.length() ==0 || s6.length() ==0 ){
				JOptionPane.showMessageDialog(this,"Please fillup all the required field to signup successfully ");
			}
			else{
				String q = "select * from `identity`";
				String a = "select * from `locations`";
				DataAccess da=new DataAccess();
				ResultSet rs_u = da.getData(q);
				ResultSet rs_a = da.getData(a);
				try{
					while(rs_u.next())
					{
						String username = rs_u.getString("username");
						//System.out.println(t1.getlength());
						if(username.equals(s1))
						{
							count  =1;
						 JOptionPane.showMessageDialog(this,"This username is already used, try with a different usename");	
						}
					}
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}                                                   //Searching for the place in the database.
				try{
					while(rs_a.next())
					{
						String place = rs_a.getString("places");
						//System.out.println(t1.getlength());
						if(place.equals(s3))                    //If there thene count_a will be 1.
						{
							count_a  =1;
						    location = rs_a.getInt("l_id");
						}
					}
					if(count_a == 0)
					{
					JOptionPane.showMessageDialog(this,"The place is unknown to us. We haven't reached there yet.");
					}
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
					
				if(count == 0 && count_a == 1){
					String ProfileName,Address,UserName,Password,Phone,Email;
					ProfileName = proname_t.getText();
					Address = address_t.getText();
					UserName = user_t.getText();
					Password = pass_t.getText();
					Phone = phone_t.getText();
					Email = email_t.getText();                                  //Inserting data into database.
				                                                                 
					q = "insert into `customers`(c_name,l_id)" + "values ('"+ProfileName+"','"+location+"')";
					da.updateDB(q);	
					q = "insert into `identity` (username,password) values ('"+UserName+"','"+Password+"')";	
					da.updateDB(q); 	
					q = "insert into `contacts_info` (phone,email) values ('"+Phone+"','"+Email+"')";
					da.updateDB(q);	
					mainWindow mW = new mainWindow();
					JOptionPane.showMessageDialog(this,"Signup successfully ! \n Please login to continue");
					this.setVisible(false);
				}
			}
				
			
	
		
		}
			
			
	}
}
	


