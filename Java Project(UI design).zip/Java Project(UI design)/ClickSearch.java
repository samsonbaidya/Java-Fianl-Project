import java.awt.Color;
import java.awt.Container;
import java.awt.TextField;
import java.awt.TextArea;
import java.awt.Button;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;



public class ClickSearch extends JFrame
{
private Container c;
private JButton search,order,expired,sold;
private JLabel search_label,product_name,quantity;
private TextField search_tf;
private Button find;
private TextArea database;
public ClickSearch()
{
	super("Search Product");
    frame();
}

public void frame()
{
    c = getContentPane();
    c.setBackground(Color.gray);
    c.setLayout(null);
    setLocationRelativeTo(null);
    setBounds(500, 500, 700, 250);
	
	search = new JButton("Search");
	//search.setRolloverIcon(img2);
    search.setBounds(0, 0, 100, 50);
    c.add(search);
    
    
    order = new JButton("Order");
    order.setBounds(0, 50, 100, 50);
    c.add(order);
    
    
    expired = new JButton("Expired");
    expired.setBounds(0, 100, 100, 50);
    c.add(expired);
    
    
    sold = new JButton("Sold");
    sold.setBounds(0, 150, 100, 50);
    c.add(sold);
    
	search_label = new JLabel("Search:");
    search_label.setBounds(180, 52, 50, 15);
    c.add(search_label);

    search_tf = new TextField();
    search_tf.setBounds(230, 50, 120, 20);
    c.add(search_tf);
    
    find = new Button("Search");
    find.setBounds(300, 80, 50, 20);
    c.add(find);
    
	database = new TextArea("all the product details and a database will be attached ...");
	database.setEditable(false);
    database.setBounds(350, 0, 1450, 920);
    c.add(database);
	
   
}

}
