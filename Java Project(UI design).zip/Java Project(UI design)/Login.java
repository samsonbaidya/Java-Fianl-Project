import java.awt.Button;
import java.awt.Color;
import java.awt.Container;
import java.awt.TextField;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Login extends JFrame
{
    private Container c;
    private JLabel userName,password;
    private TextField userName_text,password_text;
    private Button login;
    Login()
    {
		super("Login Window");
        frame();
    };
    
    public void frame()
    {
        c=this.getContentPane();
        c.setBackground(Color.gray);
        c.setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(0, 0, 500, 500);
   
        
        userName = new JLabel();
        userName.setText("User Name:");
        userName.setBounds(140, 161, 70, 15);
        c.add(userName);
  
        userName_text = new TextField();
        userName_text.setBounds(211, 160, 150, 20);
        c.add(userName_text);
        
        
        password = new JLabel();
        password.setText("Password:");
        password.setBounds(140, 221, 70, 15);
        c.add(password);
        
        password_text = new TextField();
        password_text.setBounds(211, 220, 150, 20);
        c.add(password_text);
        
        
        login = new Button("Login");
        login.setBounds(310, 260, 50, 30);
        c.add(login);
    }
	
	
    public static void main(String[] args)
    {
      
        Login loginObj = new Login();
        loginObj.setVisible(true);
        Search searchObj = new Search();
        searchObj.setVisible(true);
        Manager managerObj = new Manager();
        managerObj.setVisible(true);
		ClickSearch cls = new ClickSearch();
        cls.setVisible(true);
		Order orderObj = new Order();
		orderObj.setVisible(true);
		ExpiredProduct expiredP = new ExpiredProduct();
		expiredP.setVisible(true);
		Sold soldObj = new Sold();
		soldObj.setVisible(true);
    }
    
}
