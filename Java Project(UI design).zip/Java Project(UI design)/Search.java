import java.awt.Color;
import java.awt.Container;
import java.awt.TextField;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Search extends JFrame
{
private Container c;
private JLabel product_code,product_name,quantity;
private TextField product_code_text,product_name_text;
private JButton search,buy;
Search()
{
	super("Search Window");
    frame();
}

public void frame()
{
    c = getContentPane();
    c.setBackground(Color.gray);
    c.setLayout(null);
    setLocationRelativeTo(null);
    setBounds(0, 500, 500, 500);
    
    
    
    product_code = new JLabel("Product Code:");
   // product_code.setOpaque(true);
    product_code.setBounds(140, 81, 80, 15);
    c.add(product_code);
    
    
    product_code_text = new TextField();
    product_code_text.setBounds(221, 80, 150, 20);
    c.add(product_code_text);
    
    
    search = new JButton("Search");
    search.setBounds(285, 110, 90, 30);
    c.add(search);
    
    
    product_name = new JLabel("Product Name:");
    //product_name.setOpaque(true);
    product_name.setBounds(140, 181, 85, 15);
    c.add(product_name);
    
    
    product_name_text = new TextField();
    product_name_text.setBounds(226, 180, 150, 20);
    c.add(product_name_text);
    
    
    quantity = new JLabel("Quantity:");
    //quantity.setOpaque(true);
    quantity.setBounds(140, 240, 50, 15);
    c.add(quantity);
    
    
    buy = new JButton("Buy");
    buy.setBounds(200, 270, 60, 30);
    c.add(buy);
}

}
