import java.awt.Color;
import java.awt.Container;
import java.awt.TextArea;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.Icon;


public class ExpiredProduct extends JFrame
{
private Container c;
private JButton search,order,expired,sold,clear;
private TextArea database;
public ExpiredProduct()
{
	super("Expired Product");
    frame();
}
public void frame()
{
    
    c = getContentPane();
    c.setBackground(Color.gray);
    c.setLayout(null);
    setLocationRelativeTo(null);
	setBounds(1200, 500, 450, 250);
  
    
    Icon img1 = new ImageIcon(getClass().getResource(""));
    Icon img2 = new ImageIcon(getClass().getResource(""));
    
    search = new JButton("Search");
	search.setRolloverIcon(img2);
    search.setBounds(0, 0, 100, 50);
    c.add(search);
    
    
    order = new JButton("Order");
    order.setBounds(0, 50, 100, 50);
    c.add(order);
    
    
    expired = new JButton("Expired");
    expired.setBounds(0, 100, 100, 50);
    c.add(expired);
    
    
    sold = new JButton("Sold");
    sold.setBounds(0, 150, 100, 50);
    c.add(sold);
	
    
    
    database = new TextArea("all the product details and a database will be attached ...");
	database.setEditable(false);
    database.setBounds(100, 0, 1700, 920);
    c.add(database);
	
	clear = new JButton("Clear");
    clear.setBounds(1700, 920, 100, 50);
    c.add(clear);
	

}
    
}
