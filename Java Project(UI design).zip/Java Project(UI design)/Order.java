import java.awt.Color;
import java.awt.Container;
import java.awt.TextField;
import java.awt.TextArea;
import java.awt.Button;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;



public class Order extends JFrame
{
private Container c;
private JButton search,order,expired,sold,buy;
private JLabel productCode,productName,quantity;
private TextField productCode_tf,productName_tf,quantity_tf;

private TextArea database;
 public Order()
{
	super("Order Product");
    frame();
}

public void frame()
{
    c = getContentPane();
    c.setBackground(Color.gray);
    c.setLayout(null);
    setLocationRelativeTo(null);
    setBounds(1150, 0, 760, 400);
	
	
	
	search = new JButton("Search");
	//search.setRolloverIcon(img2);
    search.setBounds(0, 0, 100, 50);
    c.add(search);
  
    order = new JButton("Order");
    order.setBounds(0, 50, 100, 50);
    c.add(order);
    
    expired = new JButton("Expired");
    expired.setBounds(0, 100, 100, 50);
    c.add(expired);
	
    sold = new JButton("Sold");
    sold.setBounds(0, 150, 100, 50);
    c.add(sold);
	
	

	productName = new JLabel("Product Name:");
    productName.setBounds(140, 81, 90, 15);
    c.add(productName);

    productName_tf = new TextField();
    productName_tf.setBounds(230, 80, 150, 20);
    c.add(productName_tf);
	
	productCode = new JLabel("Product Code:");
    productCode.setBounds(140, 121, 80, 15);
    c.add(productCode);
    
    productCode_tf = new TextField();
    productCode_tf.setBounds(230, 120, 150, 20);
    c.add(productCode_tf);
	
	quantity = new JLabel("Quantity:");
    quantity.setBounds(140, 161, 50, 15);
    c.add(quantity);
	
	quantity_tf = new TextField();
    quantity_tf.setBounds(230, 160, 150, 20);
    c.add(quantity_tf);
	
	buy = new JButton("Buy");
    buy.setBounds(250, 250, 60, 30);
    c.add(buy);
	
	

	database = new TextArea("all the product details and a database will be attached ...");
	database.setEditable(false);
    database.setBounds(400, 0, 1400, 920);
    c.add(database);
	
   
}

}
